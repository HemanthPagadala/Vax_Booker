var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "vaccination_app" 
});

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'vaccination_app' 
});

// Export the pool for use in other modules
module.exports = pool;

function insertUser(first_name, last_name, email, password, booking_status, center, working_hours) {
  const sql = "INSERT INTO users (first_name, last_name, email, password, booking_status, centre, working_hours) VALUES (?, ?, ?, ?, ?, ?, ?)";
  const values = [first_name, last_name, email, password, booking_status, center, working_hours];

  con.query(sql, values, function (err, result) {
    if (err) throw err;
    console.log("Data inserted successfully!");
  });
}

function validateUser(email, password, callback) {
  const sql = "SELECT first_name, last_name, email, booking_status, centre, working_hours FROM users WHERE email = ? AND password = ?";
  const values = [email, password];

  pool.getConnection((err, connection) => {
    if (err) {
      callback(err, null);
      return;
    }

    connection.query(sql, values, (err, result) => {
      connection.release(); // Release the connection

      if (err) {
        callback(err, null);
      } else {
        if (result.length > 0) {
          const userDetails = result[0]; // Assuming the query only returns one row
          callback(null, userDetails); // Pass the user details to the callback
        } else {
          callback(null, false); // User does not exist or password is incorrect
        }
      }
    });
  });
}


function validateAdmin(first_name, last_name, email, password, callback) {
  const sql = "SELECT * FROM admins WHERE first_name = ? AND last_name = ? AND email = ? AND password = ?";
  const values = [first_name, last_name, email, password];

  con.query(sql, values, function (err, result) {
    if (err) {
      callback(err, null);
    } else {
      if (result.length > 0) {
        callback(null, true); // User exists and password is correct
      } else {
        callback(null, false); // User does not exist or password is incorrect
      }
    }
  });
}

module.exports = {
  insertUser,
  validateUser,
  validateAdmin
};






// function validateUser(email, password, callback) {
//   const sql = "SELECT * FROM users WHERE email = ? AND password = ?";
//   const values = [email, password];

//   con.query(sql, values, function (err, result) {
//     if (err) {
//       callback(err, null);
//     } else {
//       if (result.length > 0) {
//         const userDetails = result[0]; // Assuming the query only returns one row
//         callback(null, userDetails); // Pass the user details to the callback
//       } else {
//         callback(null, false); // User does not exist or password is incorrect
//       }
//     }
//   });
// }




